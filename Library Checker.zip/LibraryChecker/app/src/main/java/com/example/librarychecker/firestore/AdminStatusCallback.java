package com.example.librarychecker.firestore;

public interface AdminStatusCallback {
    void onChecked(boolean isAdmin);
}
